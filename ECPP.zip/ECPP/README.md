# Employee-crypto-payment-Portal
Employee crypto payment Portal using Node Js and Material-UI

For node_modules:
npm install
npm start


1]  Build Instructions
* created main employee page with title and subtitle
* search bar button
* payment Button
* Table showcasing history of payments
* onClick of payment button diaolg box will popup
* with fields like name, email, amount, description(optional) and department, crypto coin selection and date then submit or reset button

2]  Usage instructions
* drag the project on VS Code
* open terminal
* type npm install 
* it will install all the node_modules 
* then type npm start
* it will give you react app

3] Other implementaions
* implemented a history table
* Mock api included but while running got too many errors so left them 

4] Assumptions 
* First I thought it was a simple page but it is in react so i had learn quickly and implement.
* sam goes for mock api but it got me too many errors that impacted first pages so i left it

5] Problems Faced
* my system was unable to load all modules 
* most of the time went to debugging
* for installation GFG helped me a lot 
* Thank god for stackoverflow for error resolving
* while hosting website on github got errors too
* so i had check ssh public and private keys
* then got public key pasted over git
* but still got 404 error
* there was no solution so im submitting git repo.