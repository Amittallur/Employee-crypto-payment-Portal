module.exports = (req, res) => {
  const userId = req.body.id;

  if (userId === 1) {
    return res.sendStatus(401);
  }

  return res.status(401).json({
    id: req.body.id,
    userName: req.body.userName,
    age: req.body.age
  });
};

module.exports = (req, res) => {
  const userId = req.body.id;

  if (userId === 2) {
    return res.sendStatus(400);
  }

  return res.status(400).json({
    id: req.body.id,
    userName: req.body.userName,
    age: req.body.age
  });
};

module.exports = (req, res) => {
  const userId = req.body.id;

  if (userId === 3) {
    return res.sendStatus(500);
  }

  return res.status(500).json({
    id: req.body.id,
    userName: req.body.userName,
    age: req.body.age
  });
};