module.exports = (req, res) => res.sendStatus(400);
